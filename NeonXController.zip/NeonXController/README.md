# NEON X CONTROLLER 1.1
Real Bluetooth HID gamepad (BluetoothHidDevice API). Kotlin + Jetpack Compose.

New in 1.1: logo/app icon, 10 skins + custom skins (image or .json), guided Bluetooth setup
(scan, pair, auto-connect last phone).

Custom skin .json example:
{"name":"My Skin","accent":"#00F0FF","faces":["#00FF9C","#FF2E63","#3D8BFF","#FFE600"],"bg":"#021018","bgStyle":0}
bgStyle: 0 grid, 1 dots, 2 stripes, 3 pulse, 4 plain.

Build: GitHub Actions (build.yml) or Android Studio: gradle assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
Not tested on a real device or emulator; compatibility with PPSSPP/AetherSX2 is not claimed.
