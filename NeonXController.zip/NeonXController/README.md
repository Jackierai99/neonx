# NEON X CONTROLLER

Turns an Android phone into a real Bluetooth HID gamepad (BluetoothHidDevice API) for another Android phone.
No Wi-Fi, no internet, no companion app. Kotlin + Jetpack Compose.

## Requirements
- Controller phone: Android 9+ (API 28+) whose Bluetooth firmware supports the **HID Device** profile.
  This is different from HID *Host* (which almost every phone has). Some phones/ROMs disable HID Device.
  The app checks this for real and shows the exact reason in the status box. It never fakes a connection.
- Game phone: any Android with Bluetooth (it only needs normal HID *Host* support).

## Build
1. Install Android Studio (Koala or newer, JDK 17 is bundled). Open this folder (`NeonXController`).
2. Wait for Gradle sync (internet needed once to download Gradle/libraries).
3. Debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or terminal:
   `gradle assembleDebug` (if there is no `gradlew`, run `gradle wrapper --gradle-version 8.7` once).
   Output: `app/build/outputs/apk/debug/app-debug.apk`
4. Installable release-style APK: `gradle assembleRelease` -> `app/build/outputs/apk/release/app-release.apk`
   (signed with the debug key; make your own keystore before publishing).

## Permissions
BLUETOOTH, BLUETOOTH_ADMIN (Android 9-11), BLUETOOTH_CONNECT, BLUETOOTH_ADVERTISE (Android 12+, requested at runtime).

## Use
1. Open the app, allow Bluetooth permission. Status must show READY.
2. MAKE DISCOVERABLE, pair from the game phone (Settings > Bluetooth).
3. Select the game phone in the list, CONNECT. Status turns green only when Android reports a real connection.
4. In PPSSPP / AetherSX2: Controls > map each button by pressing it.

## HID layout
Report ID 1, 16 buttons (Linux/Android gamepad order: A, B, X, Y, L1, R1, L2, R2, SELECT, START, MODE, L3, R3),
hat switch (D-pad), X/Y = left stick, Z/Rz = right stick, Brake/Accelerator = analog L2/R2.

## Status
Not yet tested on a real device or with PPSSPP / AetherSX2, so emulator compatibility is NOT claimed.
Keep the app in the foreground while playing; Android may drop HID when the app is backgrounded.
