package com.neonx.controller

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

enum class Screen { SETUP, PAD, SETTINGS }

class MainActivity : ComponentActivity() {
    private lateinit var pad: HidGamepad
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pad = HidGamepad(applicationContext)
        prefs = Prefs(applicationContext)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()
        setContent { App(pad, prefs, ::openDiscoverable, ::openBtSettings, ::enableBt) }
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }
    override fun onResume() { super.onResume(); pad.refresh() }
    override fun onStop() { super.onStop(); pad.releaseAll() }          // no stuck buttons when leaving the app
    override fun onDestroy() { super.onDestroy(); pad.shutdown() }

    private fun openDiscoverable() {
        try {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
        } catch (e: Exception) { Toast.makeText(this, "Could not make this phone discoverable: " + e.message, Toast.LENGTH_LONG).show() }
    }

    private fun enableBt() {
        try { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (e: Exception) { openBtSettings() }
    }

    private fun openBtSettings() {
        try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) { }
    }
}

@Composable
fun App(pad: HidGamepad, prefs: Prefs, onDiscoverable: () -> Unit, onBtSettings: () -> Unit, onEnableBt: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.SETUP) }
    var from by remember { mutableStateOf(Screen.SETUP) }
    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_SCAN)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { pad.start() }
    // custom skin file picker (image or .json)
    val skinPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Toast.makeText(ctx, prefs.importSkin(uri), Toast.LENGTH_LONG).show()
    }
    LaunchedEffect(Unit) {
        if (pad.hasPermission() && pad.hasScanPermission()) pad.start() else permLauncher.launch(perms)
    }
    BackHandler(screen != Screen.SETUP) { screen = if (screen == Screen.SETTINGS) from else Screen.SETUP }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF00F0FF), onPrimary = Color.Black,
        background = Color.Black, surface = Color.Black, onSurface = Color.White)) {
        when (screen) {
            Screen.SETUP -> SetupScreen(pad, { screen = Screen.PAD }, { from = screen; screen = Screen.SETTINGS },
                { permLauncher.launch(perms) }, onEnableBt, onDiscoverable, onBtSettings)
            Screen.PAD -> ControllerScreen(pad, prefs, { screen = Screen.SETUP }, { from = screen; screen = Screen.SETTINGS })
            Screen.SETTINGS -> SettingsScreen(prefs, { skinPicker.launch(arrayOf("*/*")) }) { screen = from }
        }
    }
}
