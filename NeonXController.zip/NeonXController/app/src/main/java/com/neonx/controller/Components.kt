package com.neonx.controller

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.hypot
import kotlin.math.min

/** Animated cyberpunk backdrop: moving neon grid + scanline. */
@Composable
fun NeonBackground(th: Theme) {
    val tr = rememberInfiniteTransition(label = "bg")
    val ph by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "ph")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color.Black, th.bg, Color.Black)))
        val w = size.width; val h = size.height; val hz = h * 0.35f; val n = 12
        for (i in 0 until n) {
            val f = (i + ph) / n; val y = hz + (h - hz) * f * f
            drawLine(th.accent.copy(alpha = 0.22f * f), Offset(0f, y), Offset(w, y), 1.5f)
        }
        for (j in -8..8) drawLine(th.accent.copy(alpha = 0.12f), Offset(w / 2 + j * w * 0.02f, hz), Offset(w / 2 + j * w * 0.16f, h), 1.5f)
        val sy = h * ph
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, th.accent.copy(alpha = 0.10f), Color.Transparent), startY = sy - 40f, endY = sy + 40f),
            topLeft = Offset(0f, sy - 40f), size = Size(w, 80f))
    }
}

/** Glowing glass button. Sends down on touch, up on release/slide-off/cancel/removal. */
@Composable
fun NeonButton(label: String, color: Color, w: Dp, h: Dp, round: Boolean, onDown: () -> Unit, onUp: () -> Unit, modifier: Modifier = Modifier) {
    var down by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (down) 0.88f else 1f, tween(60), label = "sc")
    val glow by animateFloatAsState(if (down) 1f else 0.35f, tween(80), label = "gl")
    val dn by rememberUpdatedState(onDown)
    val up by rememberUpdatedState(onUp)
    DisposableEffect(Unit) { onDispose { if (down) { down = false; up() } } }
    Box(
        modifier.size(w, h).scale(sc)
            .drawBehind {
                val corner = if (round) size.minDimension / 2f else size.minDimension * 0.3f
                for (i in 1..4) {
                    val g = i * 3.dp.toPx()
                    drawRoundRect(color.copy(alpha = 0.09f * glow), Offset(-g, -g), Size(size.width + 2 * g, size.height + 2 * g), CornerRadius(corner + g))
                }
                drawRoundRect(Brush.verticalGradient(listOf(color.copy(alpha = 0.30f + 0.4f * glow), color.copy(alpha = 0.10f + 0.1f * glow))), cornerRadius = CornerRadius(corner))
                drawRoundRect(color, cornerRadius = CornerRadius(corner), style = Stroke(2.dp.toPx()))
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    down = true; dn()
                    waitForUpOrCancellation()
                    down = false; up()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (min(w.value, h.value) * 0.38f).sp,
            style = TextStyle(shadow = Shadow(color, Offset.Zero, 14f)))
    }
}

/** 360-degree analog stick with dead zone and sensitivity. Outputs -1..1 on both axes. */
@Composable
fun NeonStick(diameter: Dp, color: Color, sens: Float, dead: Float, onAxis: (Float, Float) -> Unit) {
    var kx by remember { mutableFloatStateOf(0f) }
    var ky by remember { mutableFloatStateOf(0f) }
    val cb by rememberUpdatedState(onAxis)
    val sn by rememberUpdatedState(sens)
    val dz by rememberUpdatedState(dead)
    DisposableEffect(Unit) { onDispose { cb(0f, 0f) } }
    Box(
        Modifier.size(diameter)
            .drawBehind {
                val r = size.minDimension / 2f; val c = center
                for (i in 1..4) drawCircle(color.copy(alpha = 0.07f), r + i * 3.dp.toPx(), c)
                drawCircle(Brush.radialGradient(listOf(Color(0x44FFFFFF), Color(0x0AFFFFFF)), c, r), r, c)
                drawCircle(color, r, c, style = Stroke(2.dp.toPx()))
                drawCircle(color.copy(alpha = 0.3f), r * 0.55f, c, style = Stroke(1.dp.toPx()))
                val kc = Offset(c.x + kx * r * 0.55f, c.y + ky * r * 0.55f)
                drawCircle(color.copy(alpha = 0.25f), r * 0.4f + 6.dp.toPx(), kc)
                drawCircle(Brush.radialGradient(listOf(Color.White.copy(0.9f), color, color.copy(0.5f)), kc, r * 0.4f), r * 0.4f, kc)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val travel = size.width / 2f * 0.55f
                    fun upd(pt: Offset) {
                        val dx = (pt.x - c.x) / travel; val dy = (pt.y - c.y) / travel
                        val len = hypot(dx, dy); val m = min(len, 1f)
                        if (len > 0f) { kx = dx / len * m; ky = dy / len * m }
                        val d = dz
                        if (len == 0f || m <= d) cb(0f, 0f)
                        else { val o = min(1f, (m - d) / (1f - d) * sn); cb(dx / len * o, dy / len * o) }
                    }
                    upd(down.position)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        upd(ch.position); ch.consume()
                    }
                    kx = 0f; ky = 0f; cb(0f, 0f)
                }
            }
    )
}

/** D-pad with 8 directions (bit0 up, bit1 down, bit2 left, bit3 right). */
@Composable
fun NeonDpad(diameter: Dp, color: Color, onDir: (Int) -> Unit) {
    var mask by remember { mutableIntStateOf(0) }
    val cb by rememberUpdatedState(onDir)
    DisposableEffect(Unit) { onDispose { cb(0) } }
    Box(
        Modifier.size(diameter)
            .drawBehind {
                val w = size.width; val a = w * 0.33f; val b = w * 0.67f
                val path = Path().apply {
                    moveTo(a, 0f); lineTo(b, 0f); lineTo(b, a); lineTo(w, a); lineTo(w, b); lineTo(b, b)
                    lineTo(b, w); lineTo(a, w); lineTo(a, b); lineTo(0f, b); lineTo(0f, a); lineTo(a, a); close()
                }
                for (i in 1..4) drawPath(path, color.copy(alpha = 0.07f), style = Stroke((2 + i * 5).dp.toPx(), join = StrokeJoin.Round))
                drawPath(path, Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x10FFFFFF))))
                drawPath(path, color, style = Stroke(2.dp.toPx(), join = StrokeJoin.Round))
                fun tri(cx: Float, cy: Float, dx: Float, dy: Float, on: Boolean) {
                    val t = w * 0.085f
                    val p = Path().apply {
                        moveTo(cx + dx * t, cy + dy * t)
                        lineTo(cx - dx * t * 0.7f - dy * t, cy - dy * t * 0.7f + dx * t)
                        lineTo(cx - dx * t * 0.7f + dy * t, cy - dy * t * 0.7f - dx * t)
                        close()
                    }
                    drawPath(p, color.copy(alpha = if (on) 1f else 0.4f))
                }
                tri(w / 2, w * 0.17f, 0f, -1f, (mask and 1) != 0)
                tri(w / 2, w * 0.83f, 0f, 1f, (mask and 2) != 0)
                tri(w * 0.17f, w / 2, -1f, 0f, (mask and 4) != 0)
                tri(w * 0.83f, w / 2, 1f, 0f, (mask and 8) != 0)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    fun upd(pt: Offset) {
                        val h = size.width / 2f
                        val dx = (pt.x - h) / h; val dy = (pt.y - h) / h
                        var m = 0
                        if (hypot(dx, dy) > 0.16f) {
                            if (dy < -0.33f) m = m or 1
                            if (dy > 0.33f) m = m or 2
                            if (dx < -0.33f) m = m or 4
                            if (dx > 0.33f) m = m or 8
                        }
                        if (m != mask) { mask = m; cb(m) }
                    }
                    upd(down.position)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        upd(ch.position); ch.consume()
                    }
                    if (mask != 0) { mask = 0; cb(0) }
                }
            }
    )
}
