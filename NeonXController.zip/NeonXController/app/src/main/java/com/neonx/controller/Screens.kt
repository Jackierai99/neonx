package com.neonx.controller

import android.annotation.SuppressLint
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

fun statusColor(s: Status) = when (s) {
    Status.CONNECTED -> Color(0xFF39FF14)
    Status.READY -> Color(0xFFFFE600)
    Status.CONNECTING, Status.STARTING -> Color(0xFFFF9100)
    else -> Color(0xFFFF3D5A)
}

fun statusLabel(p: HidGamepad) = when (p.status) {
    Status.CONNECTED -> "CONNECTED: " + p.hostName
    Status.READY -> "READY - NOT CONNECTED"
    Status.CONNECTING -> "CONNECTING..."
    Status.STARTING -> "STARTING..."
    Status.NO_PERMISSION -> "PERMISSION NEEDED"
    Status.BT_OFF -> "BLUETOOTH OFF"
    Status.UNSUPPORTED -> "NOT SUPPORTED"
    Status.ERROR -> "ERROR"
}

@Composable
fun Chip(text: String, color: Color, onClick: () -> Unit) {
    val sh = RoundedCornerShape(50)
    Box(Modifier.clip(sh).background(Color(0x33FFFFFF)).border(1.dp, color, sh).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp)) {
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** One on-screen button wired to the (remappable) HID target. */
@Composable
private fun CBtn(c: Ctl, pad: HidGamepad, p: Prefs, color: Color, w: Float, h: Float, round: Boolean, modifier: Modifier = Modifier) {
    val view = LocalView.current
    NeonButton(c.label, color, w.dp, h.dp, round,
        onDown = { pad.setButton(p.map[c.ordinal], true); view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) },
        onUp = { pad.setButton(p.map[c.ordinal], false) },
        modifier = modifier)
}

/** Landscape gamepad. Sizes scale with the screen and the "button size" setting. */
@Composable
fun ControllerScreen(pad: HidGamepad, p: Prefs, onSetup: () -> Unit, onSettings: () -> Unit) {
    val th = p.theme()
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val u = min(maxHeight.value / 360f, maxWidth.value / 780f).coerceIn(0.55f, 1.4f) * p.scale
        NeonBackground(th)
        Box(Modifier.fillMaxSize().safeDrawingPadding().padding(8.dp)) {
            // shoulders and triggers
            Row(Modifier.align(Alignment.TopStart).padding(start = (6 * u).dp), horizontalArrangement = Arrangement.spacedBy((8 * u).dp)) {
                CBtn(Ctl.L2, pad, p, th.accent, 84 * u, 38 * u, false)
                CBtn(Ctl.L1, pad, p, th.accent, 84 * u, 38 * u, false)
            }
            Row(Modifier.align(Alignment.TopEnd).padding(end = (6 * u).dp), horizontalArrangement = Arrangement.spacedBy((8 * u).dp)) {
                CBtn(Ctl.R1, pad, p, th.accent, 84 * u, 38 * u, false)
                CBtn(Ctl.R2, pad, p, th.accent, 84 * u, 38 * u, false)
            }
            // real connection status + settings
            Row(Modifier.align(Alignment.TopCenter), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("\u25CF " + statusLabel(pad), statusColor(pad.status), onSetup)
                Chip("\u2699", Color.White, onSettings)
            }
            // left: D-pad + left stick + L3
            Box(Modifier.align(Alignment.CenterStart).padding(start = (30 * u).dp).offset(y = (-22 * u).dp)) {
                NeonDpad((124 * u).dp, th.accent) { m -> pad.setDpad(m) }
            }
            Box(Modifier.align(Alignment.BottomStart).padding(start = (112 * u).dp, bottom = (4 * u).dp)) {
                NeonStick((118 * u).dp, th.accent, p.sensitivity, p.deadzone) { x, y -> pad.setLeft(x, y) }
            }
            CBtn(Ctl.L3, pad, p, th.accent, 36 * u, 36 * u, true, Modifier.align(Alignment.BottomStart).padding(start = (62 * u).dp, bottom = (10 * u).dp))
            // right: A B X Y + right stick + R3
            Box(Modifier.align(Alignment.CenterEnd).padding(end = (30 * u).dp).offset(y = (-22 * u).dp).size((150 * u).dp)) {
                val f = 52 * u
                CBtn(Ctl.Y, pad, p, th.face[3], f, f, true, Modifier.align(Alignment.TopCenter))
                CBtn(Ctl.A, pad, p, th.face[0], f, f, true, Modifier.align(Alignment.BottomCenter))
                CBtn(Ctl.X, pad, p, th.face[2], f, f, true, Modifier.align(Alignment.CenterStart))
                CBtn(Ctl.B, pad, p, th.face[1], f, f, true, Modifier.align(Alignment.CenterEnd))
            }
            Box(Modifier.align(Alignment.BottomEnd).padding(end = (112 * u).dp, bottom = (4 * u).dp)) {
                NeonStick((118 * u).dp, th.accent, p.sensitivity, p.deadzone) { x, y -> pad.setRight(x, y) }
            }
            CBtn(Ctl.R3, pad, p, th.accent, 36 * u, 36 * u, true, Modifier.align(Alignment.BottomEnd).padding(end = (62 * u).dp, bottom = (10 * u).dp))
            // center: SELECT / START
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = (18 * u).dp), horizontalArrangement = Arrangement.spacedBy((14 * u).dp)) {
                CBtn(Ctl.SELECT, pad, p, th.accent, 74 * u, 32 * u, false)
                CBtn(Ctl.START, pad, p, th.accent, 74 * u, 32 * u, false)
            }
        }
    }
}

/** Connection screen: real status, pairing help, paired-device list. */
@SuppressLint("MissingPermission")
@Composable
fun SetupScreen(pad: HidGamepad, onOpenPad: () -> Unit, onSettings: () -> Unit, onGrant: () -> Unit,
                onRetry: () -> Unit, onDiscoverable: () -> Unit, onBtSettings: () -> Unit) {
    val col = statusColor(pad.status)
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black, Color(0xFF14021A), Color.Black)))
        .safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("NEON X CONTROLLER", color = Color(0xFF00F0FF), fontSize = 26.sp, fontWeight = FontWeight.Black)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x22FFFFFF)).border(1.dp, col, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text(statusLabel(pad), color = col, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(pad.detail, color = Color(0xFFCCCCCC), fontSize = 14.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onOpenPad) { Text("OPEN CONTROLLER") }
            OutlinedButton(onClick = onSettings) { Text("SETTINGS") }
        }
        if (pad.status == Status.NO_PERMISSION) Button(onClick = onGrant) { Text("GRANT BLUETOOTH PERMISSION") }
        if (pad.status == Status.NO_PERMISSION || pad.status == Status.BT_OFF || pad.status == Status.ERROR || pad.status == Status.UNSUPPORTED)
            OutlinedButton(onClick = onRetry) { Text("RETRY") }
        Text("HOW TO CONNECT", color = Color.White, fontWeight = FontWeight.Bold)
        Text("1. Tap MAKE DISCOVERABLE here.\n2. On the game phone: Settings > Bluetooth > pair with this phone.\n" +
            "3. Come back, pick the game phone in the list below and tap CONNECT.\n" +
            "4. In PPSSPP / AetherSX2 open Controls and map the buttons (press each one to bind).",
            color = Color(0xFFCCCCCC), fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onDiscoverable) { Text("MAKE DISCOVERABLE") }
            OutlinedButton(onClick = onBtSettings) { Text("BLUETOOTH SETTINGS") }
        }
        Text("PAIRED DEVICES", color = Color.White, fontWeight = FontWeight.Bold)
        if (pad.bonded.isEmpty()) Text("None yet. Pair the game phone first.", color = Color(0xFF999999), fontSize = 13.sp)
        pad.bonded.forEach { d ->
            val name = d.name ?: d.address
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(d.address, color = Color(0xFF888888), fontSize = 11.sp)
                }
                if (pad.status == Status.CONNECTED && pad.hostName == name) OutlinedButton(onClick = { pad.disconnect() }) { Text("DISCONNECT") }
                else Button(onClick = { pad.connect(d) }, enabled = pad.status == Status.READY) { Text("CONNECT") }
            }
        }
    }
}

@Composable
fun SettingsScreen(p: Prefs, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color.Black).safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("SETTINGS", color = Color(0xFF00F0FF), fontSize = 22.sp, fontWeight = FontWeight.Black)
            Button(onClick = onBack) { Text("BACK") }
        }
        Text("Stick sensitivity: " + "%.2f".format(p.sensitivity) + "x", color = Color.White)
        Slider(p.sensitivity, { p.sensitivity = it }, valueRange = 0.5f..2f, onValueChangeFinished = { p.save() })
        Text("Dead zone: " + (p.deadzone * 100).toInt() + "%", color = Color.White)
        Slider(p.deadzone, { p.deadzone = it }, valueRange = 0f..0.4f, onValueChangeFinished = { p.save() })
        Text("Button / stick size: " + (p.scale * 100).toInt() + "%", color = Color.White)
        Slider(p.scale, { p.scale = it }, valueRange = 0.7f..1.3f, onValueChangeFinished = { p.save() })
        Text("Theme", color = Color.White, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (THEMES.map { it.name } + "Custom").forEachIndexed { i, n ->
                Chip(n, if (i == p.themeIdx) Color(0xFF00F0FF) else Color.Gray) { p.themeIdx = i; p.save() }
            }
        }
        if (p.themeIdx >= THEMES.size) {
            Text("Custom color (hue)", color = Color.White)
            Slider(p.hue, { p.hue = it }, valueRange = 0f..360f, onValueChangeFinished = { p.save() })
        }
        Text("Button mapping (tap to change what each on-screen button sends)", color = Color.White, fontWeight = FontWeight.Bold)
        Ctl.values().toList().chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c ->
                    Box(Modifier.weight(1f)) {
                        Chip(c.label + "  >  " + p.map[c.ordinal].label, Color(0xFF00F0FF)) {
                            p.map[c.ordinal] = Target.values()[(p.map[c.ordinal].ordinal + 1) % Target.values().size]; p.save()
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = { p.resetMap() }) { Text("RESET MAPPING") }
        Text("Buttons are sent as a standard HID gamepad. Emulator compatibility is not verified yet: test it yourself.",
            color = Color(0xFF888888), fontSize = 12.sp)
    }
}
