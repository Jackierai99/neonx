package com.neonx.controller

import android.annotation.SuppressLint
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

fun statusColor(s: Status) = when (s) {
    Status.CONNECTED -> Color(0xFF39FF14)
    Status.READY -> Color(0xFFFFE600)
    Status.CONNECTING, Status.STARTING -> Color(0xFFFF9100)
    else -> Color(0xFFFF3D5A)
}

fun statusLabel(p: HidGamepad) = when (p.status) {
    Status.CONNECTED -> "CONNECTED: " + p.hostName
    Status.READY -> "READY - NOT CONNECTED"
    Status.CONNECTING -> "CONNECTING..."
    Status.STARTING -> "STARTING..."
    Status.NO_PERMISSION -> "PERMISSION NEEDED"
    Status.BT_OFF -> "BLUETOOTH OFF"
    Status.UNSUPPORTED -> "NOT SUPPORTED"
    Status.ERROR -> "ERROR"
}

@Composable
fun Chip(text: String, color: Color, onClick: () -> Unit) {
    val sh = RoundedCornerShape(50)
    Box(Modifier.clip(sh).background(Color(0x33FFFFFF)).border(1.dp, color, sh).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp)) {
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** The active skin; the RGB skin animates its colors. */
@Composable
fun activeTheme(p: Prefs): Theme {
    val base = p.theme()
    val tr = rememberInfiniteTransition(label = "rgb")
    val h by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "h")
    if (!base.rgb) return base
    return Theme(base.name, Color.hsv(h % 360f, 0.9f, 1f), listOf(0f, 90f, 180f, 270f).map { Color.hsv((h + it) % 360f, 0.9f, 1f) },
        base.bg, base.bgStyle, base.fill, base.glow, true, null, base.id)
}

/** One on-screen button wired to the (remappable) HID target. */
@Composable
private fun CBtn(c: Ctl, pad: HidGamepad, p: Prefs, th: Theme, color: Color, w: Float, h: Float, round: Boolean, modifier: Modifier = Modifier) {
    val view = LocalView.current
    NeonButton(c.label, color, w.dp, h.dp, round,
        onDown = { pad.setButton(p.map[c.ordinal], true); view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) },
        onUp = { pad.setButton(p.map[c.ordinal], false) },
        modifier = modifier, fill = th.fill, glowK = th.glow)
}

/** Landscape gamepad. Sizes scale with the screen and the "button size" setting. */
@Composable
fun ControllerScreen(pad: HidGamepad, p: Prefs, onSetup: () -> Unit, onSettings: () -> Unit) {
    val th = activeTheme(p)
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val u = min(maxHeight.value / 360f, maxWidth.value / 780f).coerceIn(0.55f, 1.4f) * p.scale
        NeonBackground(th)
        Box(Modifier.fillMaxSize().safeDrawingPadding().padding(8.dp)) {
            // shoulders and triggers
            Row(Modifier.align(Alignment.TopStart).padding(start = (6 * u).dp), horizontalArrangement = Arrangement.spacedBy((8 * u).dp)) {
                CBtn(Ctl.L2, pad, p, th, th.accent, 84 * u, 38 * u, false)
                CBtn(Ctl.L1, pad, p, th, th.accent, 84 * u, 38 * u, false)
            }
            Row(Modifier.align(Alignment.TopEnd).padding(end = (6 * u).dp), horizontalArrangement = Arrangement.spacedBy((8 * u).dp)) {
                CBtn(Ctl.R1, pad, p, th, th.accent, 84 * u, 38 * u, false)
                CBtn(Ctl.R2, pad, p, th, th.accent, 84 * u, 38 * u, false)
            }
            // real connection status + settings
            Row(Modifier.align(Alignment.TopCenter), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("\u25CF " + statusLabel(pad), statusColor(pad.status), onSetup)
                Chip("\u2699", Color.White, onSettings)
            }
            // left: D-pad + left stick + L3
            Box(Modifier.align(Alignment.CenterStart).padding(start = (30 * u).dp).offset(y = (-22 * u).dp)) {
                NeonDpad((124 * u).dp, th.accent) { m -> pad.setDpad(m) }
            }
            Box(Modifier.align(Alignment.BottomStart).padding(start = (112 * u).dp, bottom = (4 * u).dp)) {
                NeonStick((118 * u).dp, th.accent, p.sensitivity, p.deadzone) { x, y -> pad.setLeft(x, y) }
            }
            CBtn(Ctl.L3, pad, p, th, th.accent, 36 * u, 36 * u, true, Modifier.align(Alignment.BottomStart).padding(start = (62 * u).dp, bottom = (10 * u).dp))
            // right: A B X Y + right stick + R3
            Box(Modifier.align(Alignment.CenterEnd).padding(end = (30 * u).dp).offset(y = (-22 * u).dp).size((150 * u).dp)) {
                val f = 52 * u
                CBtn(Ctl.Y, pad, p, th, th.face[3], f, f, true, Modifier.align(Alignment.TopCenter))
                CBtn(Ctl.A, pad, p, th, th.face[0], f, f, true, Modifier.align(Alignment.BottomCenter))
                CBtn(Ctl.X, pad, p, th, th.face[2], f, f, true, Modifier.align(Alignment.CenterStart))
                CBtn(Ctl.B, pad, p, th, th.face[1], f, f, true, Modifier.align(Alignment.CenterEnd))
            }
            Box(Modifier.align(Alignment.BottomEnd).padding(end = (112 * u).dp, bottom = (4 * u).dp)) {
                NeonStick((118 * u).dp, th.accent, p.sensitivity, p.deadzone) { x, y -> pad.setRight(x, y) }
            }
            CBtn(Ctl.R3, pad, p, th, th.accent, 36 * u, 36 * u, true, Modifier.align(Alignment.BottomEnd).padding(end = (62 * u).dp, bottom = (10 * u).dp))
            // center: SELECT / START
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = (18 * u).dp), horizontalArrangement = Arrangement.spacedBy((14 * u).dp)) {
                CBtn(Ctl.SELECT, pad, p, th, th.accent, 74 * u, 32 * u, false)
                CBtn(Ctl.START, pad, p, th, th.accent, 74 * u, 32 * u, false)
            }
        }
    }
}

@Composable
private fun Step(label: String, done: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (done) "\u2705" else "\u2B1C", fontSize = 16.sp)
        Text(label, color = if (done) Color(0xFF39FF14) else Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun DevRow(name: String, addr: String, star: Boolean, action: String, enabled: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text((if (star) "\u2B50 " else "") + name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(addr, color = Color(0xFF888888), fontSize = 11.sp)
        }
        Button(onClick = onClick, enabled = enabled) { Text(action) }
    }
}

/** Guided connection screen: 4 steps, one smart button, scan + pair + auto-connect. */
@SuppressLint("MissingPermission")
@Composable
fun SetupScreen(pad: HidGamepad, onOpenPad: () -> Unit, onSettings: () -> Unit, onGrant: () -> Unit,
                onEnableBt: () -> Unit, onDiscoverable: () -> Unit, onBtSettings: () -> Unit) {
    val col = statusColor(pad.status)
    val ready = pad.status == Status.READY || pad.status == Status.CONNECTING || pad.status == Status.CONNECTED
    val last = pad.lastBonded()
    val main: Pair<String, () -> Unit> = when {
        !pad.permOk -> "GRANT PERMISSIONS" to onGrant
        !pad.btOn -> "TURN ON BLUETOOTH" to onEnableBt
        pad.status == Status.CONNECTED -> "OPEN CONTROLLER" to onOpenPad
        pad.status == Status.READY && last != null -> ("CONNECT: " + (last.name ?: last.address)) to { pad.connect(last) }
        pad.status == Status.READY -> "FIND GAME PHONE (SCAN)" to { pad.startScan() }
        pad.status == Status.STARTING || pad.status == Status.CONNECTING -> "PLEASE WAIT..." to { }
        else -> "RETRY" to { pad.start() }
    }
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black, Color(0xFF14021A), Color.Black)))
            .safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(painterResource(R.drawable.logo), "NEON X CONTROLLER", Modifier.size(64.dp).clip(CircleShape))
            Text("NEON X CONTROLLER", color = Color(0xFF00F0FF), fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x22FFFFFF)).border(1.dp, col, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text(statusLabel(pad), color = col, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(pad.detail, color = Color(0xFFCCCCCC), fontSize = 14.sp)
        }
        Step("1  Permissions allowed", pad.permOk)
        Step("2  Bluetooth ON", pad.btOn)
        Step("3  Gamepad ready", ready)
        Step("4  Connected to game phone", pad.status == Status.CONNECTED)
        Button(onClick = main.second, enabled = main.first != "PLEASE WAIT...", modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text(main.first, fontWeight = FontWeight.Bold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onOpenPad) { Text("TEST CONTROLLER") }
            OutlinedButton(onClick = onSettings) { Text("SETTINGS") }
        }
        Chip("Auto-connect last phone: " + (if (pad.autoConnect) "ON" else "OFF"), if (pad.autoConnect) Color(0xFF39FF14) else Color.Gray) { pad.setAuto(!pad.autoConnect) }
        Text("Game phone ka Bluetooth on rakho aur uski Bluetooth settings screen khuli rakho (tabhi wo scan mein dikhega). " +
            "Pair pe tap karne ke baad dono phone pe aaya request accept karo.", color = Color(0xFFCCCCCC), fontSize = 13.sp)

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("NEARBY DEVICES", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (pad.scanning) OutlinedButton(onClick = { pad.stopScan() }) { Text("STOP") }
            else OutlinedButton(onClick = { pad.startScan() }) { Text("SCAN") }
        }
        if (pad.scanning) Text("Scanning...", color = Color(0xFFFF9100), fontSize = 13.sp)
        else if (pad.discovered.isEmpty()) Text("SCAN dabao. Naye phones yahan dikhenge.", color = Color(0xFF999999), fontSize = 13.sp)
        pad.discovered.forEach { d -> DevRow(d.name ?: "Unknown device", d.address, false, "PAIR", pad.status == Status.READY) { pad.pair(d) } }

        Text("PAIRED DEVICES", color = Color.White, fontWeight = FontWeight.Bold)
        if (pad.bonded.isEmpty()) Text("Abhi koi nahi. Upar se scan karke pair karo.", color = Color(0xFF999999), fontSize = 13.sp)
        pad.bonded.forEach { d ->
            val name = d.name ?: d.address
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text((if (last?.address == d.address) "\u2B50 " else "") + name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(d.address, color = Color(0xFF888888), fontSize = 11.sp)
                }
                if (pad.status == Status.CONNECTED && pad.hostName == name) OutlinedButton(onClick = { pad.disconnect() }) { Text("DISCONNECT") }
                else Button(onClick = { pad.connect(d) }, enabled = pad.status == Status.READY) { Text("CONNECT") }
            }
        }
        Text("AGAR DUSRA PHONE IS PHONE KO DHOONDHE", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onDiscoverable) { Text("MAKE DISCOVERABLE") }
            OutlinedButton(onClick = onBtSettings) { Text("BLUETOOTH SETTINGS") }
        }
    }
}

@Composable
fun SettingsScreen(p: Prefs, onPickSkin: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color.Black).safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("SETTINGS", color = Color(0xFF00F0FF), fontSize = 22.sp, fontWeight = FontWeight.Black)
            Button(onClick = onBack) { Text("BACK") }
        }
        Text("Stick sensitivity: " + "%.2f".format(p.sensitivity) + "x", color = Color.White)
        Slider(p.sensitivity, { p.sensitivity = it }, valueRange = 0.5f..2f, onValueChangeFinished = { p.save() })
        Text("Dead zone: " + (p.deadzone * 100).toInt() + "%", color = Color.White)
        Slider(p.deadzone, { p.deadzone = it }, valueRange = 0f..0.4f, onValueChangeFinished = { p.save() })
        Text("Button / stick size: " + (p.scale * 100).toInt() + "%", color = Color.White)
        Slider(p.scale, { p.scale = it }, valueRange = 0.7f..1.3f, onValueChangeFinished = { p.save() })

        Text("Controller skins (10 built-in + yours)", color = Color.White, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            p.all().forEach { t ->
                Chip(t.name, if (t.id == p.skinId) Color(0xFF00F0FF) else Color.Gray) { p.skinId = t.id; p.save() }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onPickSkin) { Text("ADD CUSTOM SKIN") }
            val cur = p.theme()
            if (p.isCustom(cur)) OutlinedButton(onClick = { p.deleteSkin(cur) }) { Text("DELETE THIS SKIN") }
        }
        Text("Custom skin: ek photo (png/jpg) chuno, wo background ban jayegi aur colors uske hisaab se ban jayenge. " +
            "Ya ek .json file chuno:\n{\"name\":\"My Skin\",\"accent\":\"#00F0FF\",\"faces\":[\"#00FF9C\",\"#FF2E63\",\"#3D8BFF\",\"#FFE600\"],\"bg\":\"#021018\",\"bgStyle\":0}\n" +
            "bgStyle: 0 grid, 1 dots, 2 stripes, 3 pulse, 4 plain. faces = A, B, X, Y ke colors.",
            color = Color(0xFF888888), fontSize = 12.sp)

        Text("Button mapping (tap to change what each on-screen button sends)", color = Color.White, fontWeight = FontWeight.Bold)
        Ctl.values().toList().chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c ->
                    Box(Modifier.weight(1f)) {
                        Chip(c.label + "  >  " + p.map[c.ordinal].label, Color(0xFF00F0FF)) {
                            p.map[c.ordinal] = Target.values()[(p.map[c.ordinal].ordinal + 1) % Target.values().size]; p.save()
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = { p.resetMap() }) { Text("RESET MAPPING") }
        Text("Buttons are sent as a standard HID gamepad. Emulator compatibility is not verified yet: test it yourself.",
            color = Color(0xFF888888), fontSize = 12.sp)
    }
}
