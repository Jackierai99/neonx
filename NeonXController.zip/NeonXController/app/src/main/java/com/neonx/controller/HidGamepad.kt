package com.neonx.controller

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import kotlin.math.max
import kotlin.math.roundToInt

enum class Status { UNSUPPORTED, NO_PERMISSION, BT_OFF, STARTING, READY, CONNECTING, CONNECTED, ERROR }

private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

/**
 * HID report descriptor: standard "Game Pad" (Report ID 1), 9-byte report:
 *  [0-1] 16 buttons   [2] hat (D-pad, low nibble, 8 = neutral)
 *  [3] X  [4] Y (left stick)  [5] Z  [6] Rz (right stick)  (signed -127..127)
 *  [7] Brake (L2 analog)  [8] Accelerator (R2 analog)  (0..255)
 * Button order follows the Linux/Android gamepad layout so Android maps them to
 * BUTTON_A/B/X/Y/L1/R1/L2/R2/SELECT/START/MODE/THUMBL/THUMBR automatically.
 */
private val DESCRIPTOR = bytes(
    0x05, 0x01, 0x09, 0x05, 0xA1, 0x01, 0x85, 0x01,
    0x05, 0x09, 0x19, 0x01, 0x29, 0x10, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
    0x05, 0x01, 0x09, 0x39, 0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
    0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
    0x65, 0x00, 0x75, 0x04, 0x95, 0x01, 0x81, 0x03,
    0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35,
    0x15, 0x81, 0x25, 0x7F, 0x35, 0x00, 0x45, 0x00, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
    0x05, 0x02, 0x09, 0xC5, 0x09, 0xC4, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x02, 0x81, 0x02,
    0xC0
)

/** Real Bluetooth HID *Device* (BluetoothHidDevice) wrapper: this phone acts as the gamepad. */
@SuppressLint("MissingPermission")
class HidGamepad(private val app: Context) {
    var status by mutableStateOf(Status.STARTING); private set
    var detail by mutableStateOf("Starting..."); private set
    var hostName by mutableStateOf(""); private set
    val bonded = mutableStateListOf<BluetoothDevice>()

    private val adapter: BluetoothAdapter? = app.getSystemService(BluetoothManager::class.java)?.adapter
    private val main = Handler(Looper.getMainLooper())
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var registered = false

    // ----- input state -----
    private val cnt = IntArray(16)          // press counters per HID button bit
    private var dpad = 0                    // bit0 up, bit1 down, bit2 left, bit3 right
    private var lx = 0f; private var ly = 0f; private var rx = 0f; private var ry = 0f
    private val last = ByteArray(9).also { it[2] = 8 }

    private val startTimeout = Runnable {
        if (status == Status.STARTING) setStatus(Status.ERROR,
            "Bluetooth did not confirm HID registration within 6 seconds. Toggle Bluetooth off/on and tap Retry. " +
            "If it keeps failing, this phone's firmware cannot act as a Bluetooth HID gamepad.")
    }
    private val connTimeout = Runnable {
        if (status == Status.CONNECTING) setStatus(Status.READY,
            "Connection timed out. Make sure the other phone is paired, Bluetooth is on, and try again.")
    }

    private fun setStatus(s: Status, d: String) {
        status = s; detail = d
        if (s != Status.STARTING) main.removeCallbacks(startTimeout)
        if (s != Status.CONNECTING) main.removeCallbacks(connTimeout) else { main.removeCallbacks(connTimeout); main.postDelayed(connTimeout, 15000) }
    }

    fun hasPermission() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(app, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun refreshBonded() {
        bonded.clear()
        try { if (hasPermission()) adapter?.bondedDevices?.let { bonded.addAll(it.sortedBy { d -> d.name ?: d.address }) } }
        catch (e: SecurityException) { }
    }

    /** Called on app resume: retries only if a previous attempt was blocked. */
    fun refresh() {
        refreshBonded()
        if (status == Status.NO_PERMISSION || status == Status.BT_OFF || status == Status.ERROR) start()
    }

    /** Checks hardware/OS/permission and starts the HID Device profile. Never fakes success. */
    fun start() {
        val a = adapter
        if (a == null) { setStatus(Status.UNSUPPORTED, "This device has no Bluetooth hardware."); return }
        if (!hasPermission()) { setStatus(Status.NO_PERMISSION, "Bluetooth permission is needed to act as a gamepad."); return }
        if (!a.isEnabled) { setStatus(Status.BT_OFF, "Bluetooth is turned off. Turn it on, then come back."); return }
        refreshBonded()
        if (hid != null) { if (!registered) register(); return }
        setStatus(Status.STARTING, "Starting Bluetooth HID...")
        val ok = a.getProfileProxy(app, listener, BluetoothProfile.HID_DEVICE)
        if (!ok) {
            setStatus(Status.UNSUPPORTED, "This phone's Bluetooth stack does not provide the HID Device profile " +
                "(needed to act as a gamepad). Some manufacturers disable it; an app cannot add it.")
            return
        }
        main.postDelayed(startTimeout, 6000)
    }

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HID_DEVICE) { hid = proxy as? BluetoothHidDevice; register() }
        }
        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hid = null; host = null; registered = false; releaseAll()
                if (status != Status.UNSUPPORTED) setStatus(Status.ERROR, "Bluetooth HID service stopped. Tap Retry.")
            }
        }
    }

    private fun register() {
        val h = hid ?: return
        val sdp = BluetoothHidDeviceAppSdpSettings("NEON X Controller", "Gamepad", "NEON X",
            BluetoothHidDevice.SUBCLASS1_COMBO, DESCRIPTOR)
        val qos = BluetoothHidDeviceAppQosSettings(BluetoothHidDeviceAppQosSettings.SERVICE_BEST_EFFORT,
            800, 9, 0, 11250, BluetoothHidDeviceAppQosSettings.MAX)
        val ok = h.registerApp(sdp, null, qos, ContextCompat.getMainExecutor(app), callback)
        if (!ok) setStatus(Status.ERROR, "Android refused to register the gamepad (another app may already be using the HID Device profile). Close it and tap Retry.")
    }

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@HidGamepad.registered = registered
            if (registered) {
                if (pluggedDevice != null) onConnected(pluggedDevice)
                else setStatus(Status.READY, "Ready. Pair with the other phone, then pick it below and tap Connect.")
            } else if (status != Status.UNSUPPORTED) setStatus(Status.ERROR, "Gamepad is not registered. Tap Retry.")
        }
        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            if (device == null) return
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> onConnected(device)
                BluetoothProfile.STATE_CONNECTING -> setStatus(Status.CONNECTING, "Connecting to " + (device.name ?: device.address) + "...")
                BluetoothProfile.STATE_DISCONNECTED -> if (host == null || device == host) {
                    host = null; hostName = ""; releaseAll()   // never leave buttons stuck
                    if (registered) setStatus(Status.READY, "Disconnected. Pick the other phone and tap Connect.")
                }
            }
        }
        override fun onGetReport(device: BluetoothDevice?, type: Byte, id: Byte, bufferSize: Int) {
            if (device == null) return
            if (id.toInt() == 1) hid?.replyReport(device, type, id, last.copyOf())
            else hid?.reportError(device, BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ)
        }
        override fun onSetReport(device: BluetoothDevice?, type: Byte, id: Byte, data: ByteArray?) {
            if (device != null) hid?.reportError(device, BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ)
        }
    }

    private fun onConnected(d: BluetoothDevice) {
        host = d; hostName = d.name ?: d.address
        setStatus(Status.CONNECTED, "Connected to $hostName. Inputs are being sent.")
        push(true)
    }

    fun connect(d: BluetoothDevice) {
        val h = hid ?: return
        if (status != Status.READY) { detail = "Not ready to connect (status: $status)."; return }
        setStatus(Status.CONNECTING, "Connecting to " + (d.name ?: d.address) + "...")
        if (!h.connect(d)) setStatus(Status.READY, "Android could not start the connection. Pair the other phone first and keep its Bluetooth on.")
    }

    fun disconnect() { host?.let { hid?.disconnect(it) } }

    // ----- input API (call from the main thread) -----
    fun setButton(t: Target, down: Boolean) { cnt[t.bit] = max(0, cnt[t.bit] + if (down) 1 else -1); push() }
    fun setDpad(mask: Int) { dpad = mask; push() }
    fun setLeft(x: Float, y: Float) { lx = x; ly = y; push() }
    fun setRight(x: Float, y: Float) { rx = x; ry = y; push() }

    /** Releases everything (used on disconnect, app stop, screen change) so nothing stays stuck. */
    fun releaseAll() { cnt.fill(0); dpad = 0; lx = 0f; ly = 0f; rx = 0f; ry = 0f; push(true) }

    private fun ax(v: Float) = (v.coerceIn(-1f, 1f) * 127f).roundToInt().toByte()

    private fun build(): ByteArray {
        var bits = 0
        for (i in 0..15) if (cnt[i] > 0) bits = bits or (1 shl i)
        val up = (dpad and 1) != 0; val dn = (dpad and 2) != 0; val lf = (dpad and 4) != 0; val rt = (dpad and 8) != 0
        val hat = when {
            up && rt -> 1; rt && dn -> 3; dn && lf -> 5; lf && up -> 7
            up -> 0; rt -> 2; dn -> 4; lf -> 6; else -> 8
        }
        val b = ByteArray(9)
        b[0] = bits.toByte(); b[1] = (bits shr 8).toByte(); b[2] = hat.toByte()
        b[3] = ax(lx); b[4] = ax(ly); b[5] = ax(rx); b[6] = ax(ry)
        b[7] = if (cnt[Target.L2.bit] > 0) 0xFF.toByte() else 0
        b[8] = if (cnt[Target.R2.bit] > 0) 0xFF.toByte() else 0
        return b
    }

    private fun push(force: Boolean = false) {
        val h = hid ?: return
        val d = host ?: return
        if (status != Status.CONNECTED) return
        val r = build()
        if (!force && r.contentEquals(last)) return   // only send real changes (low latency, less traffic)
        r.copyInto(last)
        h.sendReport(d, 1, r)
    }

    fun shutdown() {
        main.removeCallbacksAndMessages(null)
        releaseAll()
        try { hid?.unregisterApp() } catch (e: Exception) { }
        try { hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } } catch (e: Exception) { }
        hid = null; host = null; registered = false
    }
}
