package com.neonx.controller

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Gamepad buttons exactly as laid out in the HID report (HID button n -> bit n-1). */
enum class Target(val label: String, val bit: Int) {
    A("A", 0), B("B", 1), X("X", 3), Y("Y", 4), L1("L1", 6), R1("R1", 7),
    L2("L2", 8), R2("R2", 9), SELECT("SELECT", 10), START("START", 11),
    MODE("MODE", 12), L3("L3", 13), R3("R3", 14)
}

/** On-screen controls; each can be remapped to any Target. */
enum class Ctl(val label: String, val def: Target) {
    A("A", Target.A), B("B", Target.B), X("X", Target.X), Y("Y", Target.Y),
    L1("L1", Target.L1), R1("R1", Target.R1), L2("L2", Target.L2), R2("R2", Target.R2),
    L3("L3", Target.L3), R3("R3", Target.R3), SELECT("SELECT", Target.SELECT), START("START", Target.START)
}

/**
 * A controller skin. face = colors for A, B, X, Y.
 * bgStyle: 0 grid, 1 dots, 2 stripes, 3 radial pulse, 4 plain. fill/glow tune the button look.
 */
class Theme(
    val name: String, val accent: Color, val face: List<Color>, val bg: Color,
    val bgStyle: Int = 0, val fill: Float = 0.3f, val glow: Float = 1f, val rgb: Boolean = false,
    val image: ImageBitmap? = null, val id: String = name
)

private fun c(v: Long) = Color(v)

/** The 10 built-in skins. */
val THEMES = listOf(
    Theme("Cyber Cyan", c(0xFF00F0FF), listOf(c(0xFF00FF9C), c(0xFFFF2E63), c(0xFF3D8BFF), c(0xFFFFE600)), c(0xFF021018), 0),
    Theme("Magenta Storm", c(0xFFFF2BD6), listOf(c(0xFFFF2BD6), c(0xFFB44DFF), c(0xFF4DA6FF), c(0xFFFFD84D)), c(0xFF14021A), 0),
    Theme("Toxic Green", c(0xFF39FF14), listOf(c(0xFF39FF14), c(0xFFFFEA00), c(0xFF00E5FF), c(0xFFFF3D3D)), c(0xFF021402), 1),
    Theme("Solar Flare", c(0xFFFF7A00), listOf(c(0xFFFFB300), c(0xFFFF2D2D), c(0xFFFF6E40), c(0xFFFFEE58)), c(0xFF1A0800), 2),
    Theme("Ice Blue", c(0xFF7DD3FF), listOf(c(0xFF7DD3FF), c(0xFFB3E5FF), c(0xFF4FC3F7), c(0xFFE1F5FE)), c(0xFF04101C), 1, 0.15f, 0.6f),
    Theme("Blood Red", c(0xFFFF1744), listOf(c(0xFFFF1744), c(0xFFFF5252), c(0xFFD50000), c(0xFFFF8A80)), c(0xFF1A0004), 3, 0.55f, 1f),
    Theme("Gold Luxe", c(0xFFFFD54A), listOf(c(0xFFFFD54A), c(0xFFFFC107), c(0xFFFFE082), c(0xFFFFB300)), c(0xFF0F0A00), 4, 0.45f, 0.7f),
    Theme("Stealth", c(0xFFE0E0E0), listOf(c(0xFFE0E0E0), c(0xFFBDBDBD), c(0xFF9E9E9E), c(0xFFF5F5F5)), c(0xFF050505), 4, 0.08f, 0.15f),
    Theme("Retro Arcade", c(0xFFFFEB3B), listOf(c(0xFF4CAF50), c(0xFFF44336), c(0xFF2196F3), c(0xFFFFEB3B)), c(0xFF10002A), 2, 0.5f, 1f),
    Theme("RGB Rainbow", c(0xFFFF00FF), listOf(c(0xFFFF0000), c(0xFF00FF00), c(0xFF0000FF), c(0xFFFFFF00)), c(0xFF050510), 0, 0.3f, 1f, true)
)

/** Persistent user settings + custom skins (stored in app files/skins). */
class Prefs(ctx: Context) {
    private val app = ctx.applicationContext
    private val sp = app.getSharedPreferences("neonx", Context.MODE_PRIVATE)
    private val dir = File(app.filesDir, "skins").apply { mkdirs() }

    var sensitivity by mutableFloatStateOf(sp.getFloat("sens", 1f))
    var deadzone by mutableFloatStateOf(sp.getFloat("dead", 0.12f))
    var scale by mutableFloatStateOf(sp.getFloat("scale", 1f))
    var skinId by mutableStateOf(sp.getString("skin", THEMES[0].id) ?: THEMES[0].id)
    val custom = mutableStateListOf<Theme>()
    val map = mutableStateListOf<Target>().also { l ->
        Ctl.values().forEach { k ->
            l.add(Target.values().getOrElse(sp.getInt("map_" + k.name, k.def.ordinal)) { k.def })
        }
    }

    init { loadCustom() }

    fun all(): List<Theme> = THEMES + custom
    fun theme(): Theme = all().firstOrNull { it.id == skinId } ?: THEMES[0]
    fun isCustom(t: Theme) = custom.any { it.id == t.id }

    private fun col(s: String) = Color(android.graphics.Color.parseColor(s))

    private fun loadSkin(f: File): Theme? = try {
        val j = JSONObject(f.readText())
        val id = f.nameWithoutExtension
        val accent = col(j.getString("accent"))
        val fc = j.optJSONArray("faces")
        val faces = List(4) { i -> if (fc != null && i < fc.length()) col(fc.getString(i)) else accent }
        val imgName = j.optString("image", "")
        val imgFile = if (imgName.isNotEmpty()) File(dir, imgName) else null
        val img = if (imgFile != null && imgFile.exists()) BitmapFactory.decodeFile(imgFile.path)?.asImageBitmap() else null
        Theme(j.optString("name", id), accent, faces, col(j.optString("bg", "#050510")),
            j.optInt("bgStyle", if (img != null) 4 else 0), j.optDouble("fill", 0.3).toFloat(), j.optDouble("glow", 1.0).toFloat(), false, img, id)
    } catch (e: Exception) { null }

    private fun loadCustom() {
        custom.clear()
        dir.listFiles()?.filter { it.extension == "json" }?.sortedBy { it.name }?.forEach { f -> loadSkin(f)?.let { custom.add(it) } }
    }

    /** Add a skin from a file the user picked: an image (becomes the background) or a .json with colors. */
    fun importSkin(uri: Uri): String {
        return try {
            val cr = app.contentResolver
            val mime = cr.getType(uri) ?: ""
            var name = "skin"
            cr.query(uri, null, null, null, null)?.use { cur ->
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cur.moveToFirst() && i >= 0) name = cur.getString(i)
            }
            val base = name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "skin" }
            var id = base
            var n = 1
            while (File(dir, "$id.json").exists()) id = base + "_" + (n++)
            val bytes = cr.openInputStream(uri)!!.use { it.readBytes() }
            if (mime.startsWith("image/") || name.lowercase().let { it.endsWith(".png") || it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".webp") }) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / s > 1600 || o.outHeight / s > 1600) s *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                    ?: return "Image padh nahi payi."
                File(dir, "$id.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                // accent color = average color of the picture, made bright
                val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
                val hsv = FloatArray(3)
                android.graphics.Color.colorToHSV(px, hsv)
                val hex = List(4) { k ->
                    String.format("#%06X", android.graphics.Color.HSVToColor(floatArrayOf((hsv[0] + k * 60f) % 360f, 0.85f, 1f)) and 0xFFFFFF)
                }
                val j = JSONObject().put("name", base).put("accent", hex[0]).put("faces", JSONArray(hex))
                    .put("bg", "#050510").put("image", "$id.jpg").put("bgStyle", 4)
                File(dir, "$id.json").writeText(j.toString())
            } else {
                val j = JSONObject(String(bytes))
                col(j.getString("accent"))   // validates the color
                File(dir, "$id.json").writeText(j.toString())
            }
            loadCustom()
            skinId = id
            save()
            "Skin add ho gayi: $base"
        } catch (e: Exception) {
            "Skin file sahi nahi hai: " + e.message
        }
    }

    fun deleteSkin(t: Theme) {
        if (!isCustom(t)) return
        File(dir, t.id + ".json").delete(); File(dir, t.id + ".jpg").delete()
        loadCustom()
        skinId = THEMES[0].id
        save()
    }

    fun resetMap() { Ctl.values().forEach { map[it.ordinal] = it.def }; save() }

    fun save() {
        val e = sp.edit()
        e.putFloat("sens", sensitivity); e.putFloat("dead", deadzone); e.putFloat("scale", scale)
        e.putString("skin", skinId)
        Ctl.values().forEach { e.putInt("map_" + it.name, map[it.ordinal].ordinal) }
        e.apply()
    }
}
