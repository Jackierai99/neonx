package com.neonx.controller

import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

/** Gamepad buttons exactly as laid out in the HID report (HID button n -> bit n-1). */
enum class Target(val label: String, val bit: Int) {
    A("A", 0), B("B", 1), X("X", 3), Y("Y", 4), L1("L1", 6), R1("R1", 7),
    L2("L2", 8), R2("R2", 9), SELECT("SELECT", 10), START("START", 11),
    MODE("MODE", 12), L3("L3", 13), R3("R3", 14)
}

/** On-screen controls; each can be remapped to any Target. */
enum class Ctl(val label: String, val def: Target) {
    A("A", Target.A), B("B", Target.B), X("X", Target.X), Y("Y", Target.Y),
    L1("L1", Target.L1), R1("R1", Target.R1), L2("L2", Target.L2), R2("R2", Target.R2),
    L3("L3", Target.L3), R3("R3", Target.R3), SELECT("SELECT", Target.SELECT), START("START", Target.START)
}

/** face = colors for A, B, X, Y */
class Theme(val name: String, val accent: Color, val face: List<Color>, val bg: Color)

val THEMES = listOf(
    Theme("Cyber Cyan", Color(0xFF00F0FF), listOf(Color(0xFF00FF9C), Color(0xFFFF2E63), Color(0xFF3D8BFF), Color(0xFFFFE600)), Color(0xFF021018)),
    Theme("Magenta Storm", Color(0xFFFF2BD6), listOf(Color(0xFFFF2BD6), Color(0xFFB44DFF), Color(0xFF4DA6FF), Color(0xFFFFD84D)), Color(0xFF14021A)),
    Theme("Toxic Green", Color(0xFF39FF14), listOf(Color(0xFF39FF14), Color(0xFFFFEA00), Color(0xFF00E5FF), Color(0xFFFF3D3D)), Color(0xFF021402)),
    Theme("Solar Flare", Color(0xFFFF7A00), listOf(Color(0xFFFFB300), Color(0xFFFF2D2D), Color(0xFFFF6E40), Color(0xFFFFEE58)), Color(0xFF1A0800))
)

/** Persistent user settings (SharedPreferences) exposed as Compose state. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("neonx", Context.MODE_PRIVATE)
    var sensitivity by mutableFloatStateOf(sp.getFloat("sens", 1f))
    var deadzone by mutableFloatStateOf(sp.getFloat("dead", 0.12f))
    var scale by mutableFloatStateOf(sp.getFloat("scale", 1f))
    var themeIdx by mutableIntStateOf(sp.getInt("theme", 0))   // THEMES.size = custom hue theme
    var hue by mutableFloatStateOf(sp.getFloat("hue", 280f))
    val map = mutableStateListOf<Target>().also { l ->
        Ctl.values().forEach { c ->
            l.add(Target.values().getOrElse(sp.getInt("map_" + c.name, c.def.ordinal)) { c.def })
        }
    }

    fun theme(): Theme {
        if (themeIdx < THEMES.size) return THEMES[themeIdx]
        val h = hue
        return Theme("Custom", Color.hsv(h % 360f, 0.9f, 1f),
            listOf(0f, 90f, 180f, 270f).map { Color.hsv((h + it) % 360f, 0.85f, 1f) },
            Color.hsv(h % 360f, 0.8f, 0.10f))
    }

    fun resetMap() { Ctl.values().forEach { map[it.ordinal] = it.def }; save() }

    fun save() {
        val e = sp.edit()
        e.putFloat("sens", sensitivity); e.putFloat("dead", deadzone); e.putFloat("scale", scale)
        e.putInt("theme", themeIdx); e.putFloat("hue", hue)
        Ctl.values().forEach { e.putInt("map_" + it.name, map[it.ordinal].ordinal) }
        e.apply()
    }
}
